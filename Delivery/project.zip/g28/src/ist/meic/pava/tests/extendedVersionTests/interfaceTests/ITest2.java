package ist.meic.pava.tests.extendedVersionTests.interfaceTests;

public interface ITest2 {

}
