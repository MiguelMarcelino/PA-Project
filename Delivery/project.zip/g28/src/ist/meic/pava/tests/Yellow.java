package ist.meic.pava.tests;

public class Yellow extends Color {
}
