package ist.meic.pava.tests;

public class Crayon extends Brush {
}
