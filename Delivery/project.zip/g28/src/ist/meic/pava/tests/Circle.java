package ist.meic.pava.tests;

public class Circle extends Shape{
}
