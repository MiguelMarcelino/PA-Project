package ist.meic.pava.tests;

public class Brush {
}
