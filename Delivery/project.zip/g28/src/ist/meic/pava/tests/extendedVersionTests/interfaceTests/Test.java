package ist.meic.pava.tests.extendedVersionTests.interfaceTests;

public class Test {
}
