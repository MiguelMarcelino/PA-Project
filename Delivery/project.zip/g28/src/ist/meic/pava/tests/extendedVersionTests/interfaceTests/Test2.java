package ist.meic.pava.tests.extendedVersionTests.interfaceTests;

public class Test2 extends Test implements ITest2, ITest1  {
}
