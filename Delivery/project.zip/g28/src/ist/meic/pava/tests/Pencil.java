package ist.meic.pava.tests;

public class Pencil extends Brush {
}
