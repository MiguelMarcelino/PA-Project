package ist.meic.pava.tests;

public class Line extends Shape{
}
