package ist.meic.pava.tests.extendedVersionTests.interfaceTests;

public class Test1 extends Test implements ITest2, ITest1, ITest3 {
}
