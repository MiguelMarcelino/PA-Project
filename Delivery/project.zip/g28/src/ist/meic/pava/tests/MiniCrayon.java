package ist.meic.pava.tests;

public class MiniCrayon extends Crayon {
}
