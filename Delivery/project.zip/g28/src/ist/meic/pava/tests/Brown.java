package ist.meic.pava.tests;

public class Brown extends Color {
}
